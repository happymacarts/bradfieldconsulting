'use strict';

require('../common');

const runBenchmark = require('../common/benchmark');

runBenchmark('os', ['n=1']);
